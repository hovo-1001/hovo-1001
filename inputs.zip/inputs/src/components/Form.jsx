import { useState } from "react";
import "./css/Form.css"

export const Form = (props) => {

    const [name, setName] = useState('name')
    const [lname, setLname] = useState('lname')
    const [pass, setPass] = useState('pass')
    const [mail, setMail] = useState('mail')
    const [result, setResult] = useState(null);

    const clickme = () => {
        if (name === '' || lname === '' || pass === '' || mail === '') {
            setResult('դու ոչինչ չես գրում ?');
        } else {
            setResult('Ամեն ինչ կատարյալ է');
        }
    };

    return (
        <div className="opshi">
            <div className="bgfoto"></div>
        <div className="inputbox">
            <div className="box"></div>
            <input value={name} className="name" onChange={(e) => setName(e.target.value)} />
            <input value={lname} className="lname" onChange={(e) => setLname(e.target.value)} />
            <input value={pass} className="pass" onChange={(e) => setPass(e.target.value)} />
            <input value={mail} className="mail" onChange={(e) => setMail(e.target.value)} />
            <button onClick={clickme}>մուտք</button>
            {result && <p>{result}</p>}
        </div>
        </div>
    );

}